# BasicBankingSystem
Sparks Foundation Web Development Internship Project : Basic Banking System website. 
A web application used to tranfer virtual money between multiple users and also record the banking transactions/ activities.

## The website has the following specification -
  Start with a dummy data for upto 10 customers.
  Customers table with basic fields such as name, email, current balance etc.
 Transaction status:
 Transfer table/ Transfer History which records all the transactions

Flow : Home Page > View all customers > Select and View one customer > Transfer Money > Select customer to transfer to > View all Customers.
