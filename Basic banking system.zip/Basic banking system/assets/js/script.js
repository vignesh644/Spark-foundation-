let myAccountBalance = parseInt(document.getElementById("myAccountBalance").innerText);

function sendMoney(){
   var Uname = document.getElementById("fullname").value;
   var userName = document.getElementById("userName").value;
   var enterAmount = parseInt(document.getElementById("enterAmount").value);

  // send money modal
   if (enterAmount > 10000) {
      alert("Insufficient Balance!")
   }
   else {
      var findUserBankAccount = userName + "BankBalance";
      var finalAmount = parseInt(document.getElementById(findUserBankAccount).innerHTML) + enterAmount;
      var myAccountBalance = parseInt(document.getElementById("myAccountBalance").innerText) - enterAmount
      document.getElementById("myAccountBalance").innerText = myAccountBalance
      document.getElementById(findUserBankAccount).innerHTML = finalAmount;
      alert(`Successful Transaction !!  
      $${enterAmount} is sent to ${userName}@email.com.`)

      // transaction history 
      var createPTag = document.createElement("li");
      var textNode = document.createTextNode(`The amount for ${Uname}  Rs${enterAmount} is sent to recepient with Email-id ${userName}@email.com on ${Date()}.`);
      createPTag.appendChild(textNode);
      var element = document.getElementById("transaction-history-body");
      element.insertBefore(createPTag, element.firstChild);
   }
}

